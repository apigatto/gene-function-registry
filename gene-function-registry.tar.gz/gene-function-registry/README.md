# gene-function-registry
A set of records (pages) for collecting information about gene function in a human- and machine-readable format.
